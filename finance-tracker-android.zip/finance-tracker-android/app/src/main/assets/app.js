/* ============================================================
   Fineants — manual finance tracker
   Plain JS, no framework, no build step. State lives in
   localStorage. All math is done by hand below (no chart libs).
   ============================================================ */

const STORAGE_KEY = 'tokiFinanceData'; // unchanged so existing saved data isn't orphaned
const CURRENCY = '₹';

const CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Other'];
const CATEGORY_COLORS = {
  Food: 'bar-orange',
  Transport: 'bar-blue',
  Shopping: 'bar-pink',
  Bills: 'bar-green',
  Entertainment: 'bar-purple',
  Health: 'bar-yellow',
  Other: 'bar-red'
};

const X_ICON = '<svg viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#111" stroke-width="3" stroke-linecap="round"/></svg>';

let state = loadState();
let selectedCategory = null;

/* ===================== State ===================== */

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    try { return JSON.parse(raw); } catch (e) { /* fall through to defaults */ }
  }
  return {
    userName: 'Joash',
    balance: 23000,
    banks: [
      { id: uid(), name: 'HDFC Savings', balance: 15200 },
      { id: uid(), name: 'SBI Current', balance: 7800 }
    ],
    goals: [
      { id: uid(), name: 'New Headphones', target: 8000, saved: 3200, monthly: 1000 }
    ],
    loans: [],
    expenses: []
  };
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

/* ===================== Helpers ===================== */

function esc(str) {
  return String(str).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
}

function formatMoney(n) {
  n = Number(n) || 0;
  const sign = n < 0 ? '-' : '';
  return sign + CURRENCY + Math.round(Math.abs(n)).toLocaleString('en-IN');
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

function sameMonth(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}

function loanNet() {
  return state.loans.reduce((sum, l) => sum + (l.direction === 'owed_to_me' ? l.amount : -l.amount), 0);
}

/* Simple math: months to hit a savings goal at a fixed monthly contribution */
function monthsToGoal(target, saved, monthly) {
  const remaining = target - saved;
  if (remaining <= 0) return 0;
  if (monthly <= 0) return null;
  return Math.ceil(remaining / monthly);
}

function describeGoalPrediction(target, saved, monthly) {
  const remaining = target - saved;
  if (remaining <= 0) {
    return `You've already saved enough for this — <strong>${formatMoney(saved)}</strong> saved of ${formatMoney(target)}.`;
  }
  const months = monthsToGoal(target, saved, monthly);
  if (months === null) {
    return `You need <strong>${formatMoney(remaining)}</strong> more. Add a monthly contribution above to get a time estimate.`;
  }
  const d = new Date();
  d.setMonth(d.getMonth() + months);
  const dateStr = d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  const monthLabel = months === 1 ? '1 month' : `${months} months`;
  return `Saving <strong>${formatMoney(monthly)}</strong>/month, you'll reach <strong>${formatMoney(target)}</strong> in <strong>${monthLabel}</strong> — around <strong>${dateStr}</strong>.`;
}

/* ===================== Toast ===================== */

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-visible'), 1800);
}

/* ===================== Modal shell ===================== */

const overlay = document.getElementById('modalOverlay');
const modalBody = document.getElementById('modalBody');

function openModal(html) {
  modalBody.innerHTML = html;
  overlay.classList.add('is-open');
}
function closeModal() {
  overlay.classList.remove('is-open');
  modalBody.innerHTML = '';
}

overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

modalBody.addEventListener('click', e => {
  if (e.target.closest('[data-close]')) { closeModal(); return; }

  const segBtn = e.target.closest('.segmented button');
  if (segBtn) {
    const seg = segBtn.parentElement;
    seg.querySelectorAll('button').forEach(b => b.classList.remove('is-active'));
    segBtn.classList.add('is-active');
    const hiddenName = seg.dataset.hiddenInput;
    const form = seg.closest('form');
    if (form && hiddenName && form.elements[hiddenName]) form.elements[hiddenName].value = segBtn.dataset.value;
    if (hiddenName === 'type') {
      const catField = document.getElementById('fieldCategory');
      if (catField) catField.style.display = segBtn.dataset.value === 'expense' ? '' : 'none';
      const bankField = document.getElementById('fieldBank');
      if (bankField) bankField.style.display = segBtn.dataset.value === 'expense' ? '' : 'none';
      const heading = modalBody.querySelector('.modal-head h3');
      if (heading) heading.textContent = segBtn.dataset.value === 'expense' ? 'Add expense' : 'Add income';
    }
    return;
  }

  const actionBtn = e.target.closest('[data-action]');
  if (actionBtn) handleModalAction(actionBtn.dataset.action, actionBtn.dataset.id);
});

modalBody.addEventListener('change', e => {
  if (e.target.name === 'goalId') {
    const g = state.goals.find(g => g.id === e.target.value);
    const form = e.target.closest('form');
    if (g && form) {
      form.elements.target.value = g.target;
      form.elements.saved.value = g.saved;
      if (g.monthly) form.elements.monthly.value = g.monthly;
    }
  }
});

modalBody.addEventListener('submit', e => {
  e.preventDefault();
  const form = e.target;
  // Use getAttribute, not form.id — a hidden <input name="id"> in the
  // form clobbers the form's own .id property with that element.
  const formId = form.getAttribute('id');
  const data = Object.fromEntries(new FormData(form).entries());
  if (formId === 'formTxn') submitTxn(data);
  else if (formId === 'formBank') submitBank(data);
  else if (formId === 'formGoal') submitGoal(data);
  else if (formId === 'formLoan') submitLoan(form, data);
  else if (formId === 'formLoanEdit') submitLoanEdit(data);
  else if (formId === 'formCalc') submitCalc(data);
});

function resetSegmented(form) {
  form.querySelectorAll('.segmented').forEach(seg => {
    seg.querySelectorAll('button').forEach((b, i) => b.classList.toggle('is-active', i === 0));
  });
}

function handleModalAction(action, id) {
  if (action === 'delete-bank') {
    const bank = state.banks.find(b => b.id === id);
    if (bank) state.balance -= bank.balance;
    state.banks = state.banks.filter(b => b.id !== id);
    saveState(); closeModal(); renderHome(); toast('Account removed');
  } else if (action === 'delete-goal') {
    state.goals = state.goals.filter(g => g.id !== id);
    saveState(); closeModal(); renderHome(); toast('Goal removed');
  } else if (action === 'delete-loan') {
    state.loans = state.loans.filter(l => l.id !== id);
    saveState();
    openModal(loansModalHtml()); fillLoanModal();
    renderHome(); toast('Loan removed');
  } else if (action === 'delete-expense') {
    deleteExpense(id);
  } else if (action === 'edit-loan') {
    const loan = state.loans.find(l => l.id === id);
    if (loan) openModal(loanEditHtml(loan));
  } else if (action === 'back-to-loans') {
    openModal(loansModalHtml()); fillLoanModal();
  }
}

/* ===================== Screen switching ===================== */

function switchScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('is-active', s.id === 'screen-' + name));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('is-active', b.dataset.screen === name));
  if (name === 'dashboard') renderDashboard();
}

/* ===================== Home rendering ===================== */

function renderHome() {
  document.getElementById('userName').textContent = state.userName;

  const monthSpend = state.expenses
    .filter(e => sameMonth(new Date(e.date), new Date()))
    .reduce((s, e) => s + e.amount, 0);
  document.getElementById('monthSpendValue').textContent = formatMoney(monthSpend);

  renderBankList();
  renderGoals();

  const net = loanNet();
  const mini = document.getElementById('loanSummaryMini');
  if (!state.loans.length) mini.textContent = 'Who owes who';
  else if (net > 0) mini.textContent = `You're owed ${formatMoney(net)} net`;
  else if (net < 0) mini.textContent = `You owe ${formatMoney(Math.abs(net))} net`;
  else mini.textContent = 'All settled up';
}

function renderBankList() {
  const list = document.getElementById('bankList');
  if (!state.banks.length) {
    list.innerHTML = '<li class="bank-empty">No accounts added yet.</li>';
    return;
  }
  list.innerHTML = state.banks.map(b => `
    <li class="bank-item" data-id="${b.id}">
      <div>
        <div class="bank-item-name">${esc(b.name)}</div>
        <div class="bank-item-sub">Tap to edit</div>
      </div>
      <div class="bank-item-balance">${formatMoney(b.balance)}</div>
    </li>
  `).join('');
}

function renderGoals() {
  const wrap = document.getElementById('goalList');
  const cards = state.goals.map(g => {
    const pct = g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 100)) : 0;
    return `
      <button class="goal-card" data-id="${g.id}">
        <h4>${esc(g.name)}</h4>
        <div class="goal-progress"><div class="goal-progress-fill" style="width:${pct}%"></div></div>
        <div class="goal-nums"><span>${pct}%</span><strong>${formatMoney(g.saved)} / ${formatMoney(g.target)}</strong></div>
      </button>`;
  }).join('');
  wrap.innerHTML = cards + `<button class="add-goal-card" id="btnAddGoalInline" title="Add goal">+</button>`;
}

/* ===================== Dashboard rendering ===================== */

function renderDashboard() { renderChart(); }

function renderChart() {
  const totals = {};
  state.expenses.forEach(e => { totals[e.category] = (totals[e.category] || 0) + e.amount; });
  const cats = Object.keys(totals).filter(c => totals[c] > 0);

  const chartBars = document.getElementById('chartBars');
  const chartEmpty = document.getElementById('chartEmpty');

  if (!cats.length) {
    chartBars.innerHTML = '';
    chartBars.classList.add('is-empty');
    chartEmpty.textContent = "No expenses logged yet — add one to see your graph.";
    renderDetailList(null);
    return;
  }
  chartBars.classList.remove('is-empty');

  cats.sort((a, b) => totals[b] - totals[a]);
  const max = Math.max(...cats.map(c => totals[c]));

  chartBars.innerHTML = cats.map(cat => {
    const pct = Math.max(10, Math.round((totals[cat] / max) * 100));
    const colorClass = CATEGORY_COLORS[cat] || 'bar-purple';
    const selected = cat === selectedCategory ? 'is-selected' : '';
    return `
      <button class="chart-bar ${selected}" data-cat="${esc(cat)}">
        <span class="chart-bar-value">${formatMoney(totals[cat])}</span>
        <span class="chart-bar-fill ${colorClass}" style="height:${pct}%"></span>
        <span class="chart-bar-label">${esc(cat)}</span>
      </button>`;
  }).join('');

  renderDetailList(cats.includes(selectedCategory) ? selectedCategory : null);
}

function renderDetailList(category) {
  const title = document.getElementById('detailTitle');
  const list = document.getElementById('detailList');
  const items = state.expenses
    .filter(e => !category || e.category === category)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  title.textContent = category ? category : 'All categories';

  if (!items.length) {
    list.innerHTML = `<li class="bank-empty">No expenses ${category ? 'in this category' : 'yet'}.</li>`;
    return;
  }

  list.innerHTML = items.map(e => `
    <li class="detail-item">
      <div class="detail-item-main">
        <div class="detail-item-cat">${esc(e.category)}</div>
        <div class="detail-item-note">${esc(e.note || formatDate(e.date))}</div>
      </div>
      <div class="detail-item-right">
        <span class="detail-item-amount">${formatMoney(e.amount)}</span>
        <button class="icon-btn-x" data-action="delete-expense" data-id="${e.id}" title="Delete">${X_ICON}</button>
      </div>
    </li>
  `).join('');
}

function deleteExpense(id) {
  const exp = state.expenses.find(e => e.id === id);
  if (!exp) return;
  state.balance += exp.amount;
  if (exp.bankId) {
    const bank = state.banks.find(b => b.id === exp.bankId);
    if (bank) bank.balance += exp.amount;
  }
  state.expenses = state.expenses.filter(e => e.id !== id);
  saveState();
  renderDashboard();
  renderHome();
  toast('Expense deleted');
}

/* ===================== Modal templates ===================== */

function txnModalHtml(defaultType) {
  const isExpense = defaultType !== 'income';
  const catOptions = CATEGORIES.map(c => `<option value="${c}">${c}</option>`).join('');
  const bankOptions = state.banks.map(b => `<option value="${b.id}">${esc(b.name)} (${formatMoney(b.balance)})</option>`).join('');
  return `
    <div class="modal-head"><h3>${isExpense ? 'Add expense' : 'Add income'}</h3><button class="modal-close" data-close>${X_ICON}</button></div>
    <form id="formTxn">
      <input type="hidden" name="type" value="${isExpense ? 'expense' : 'income'}">
      <div class="segmented" data-hidden-input="type" style="margin-bottom:14px">
        <button type="button" class="${isExpense ? 'is-active' : ''}" data-value="expense">Expense</button>
        <button type="button" class="${!isExpense ? 'is-active' : ''}" data-value="income">Income</button>
      </div>
      <div class="field" id="fieldCategory" style="${isExpense ? '' : 'display:none'}">
        <label>Category</label>
        <select name="category">${catOptions}</select>
      </div>
      <div class="field" id="fieldBank" style="${isExpense ? '' : 'display:none'}">
        <label>Pay from</label>
        ${state.banks.length ? `<select name="bankId">${bankOptions}</select>` : `<p class="bank-empty">No accounts yet — add one first.</p>`}
      </div>
      <div class="field">
        <label>Amount</label>
        <input name="amount" type="number" min="0" step="0.01" required placeholder="0" autofocus>
      </div>
      <div class="field">
        <label>Note (optional)</label>
        <input name="note" type="text" placeholder="e.g. Groceries at DMart">
      </div>
      <div class="btn-row"><button type="submit" class="btn btn-primary">Save</button></div>
    </form>
  `;
}

function bankFormHtml(existing) {
  return `
    <div class="modal-head"><h3>${existing ? 'Edit account' : 'Add bank account'}</h3><button class="modal-close" data-close>${X_ICON}</button></div>
    <form id="formBank">
      <input type="hidden" name="id" value="${existing ? existing.id : ''}">
      <div class="field"><label>Account name</label><input name="name" required value="${existing ? esc(existing.name) : ''}" placeholder="e.g. HDFC Savings" autofocus></div>
      <div class="field"><label>Balance</label><input name="balance" type="number" step="0.01" required value="${existing ? existing.balance : ''}"></div>
      <div class="btn-row">
        ${existing ? `<button type="button" class="btn btn-danger" data-action="delete-bank" data-id="${existing.id}">Delete</button>` : ''}
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  `;
}

function goalFormHtml(existing) {
  return `
    <div class="modal-head"><h3>${existing ? 'Edit goal' : 'New goal'}</h3><button class="modal-close" data-close>${X_ICON}</button></div>
    <form id="formGoal">
      <input type="hidden" name="id" value="${existing ? existing.id : ''}">
      <div class="field"><label>What are you saving for?</label><input name="name" required value="${existing ? esc(existing.name) : ''}" placeholder="e.g. New Headphones" autofocus></div>
      <div class="field"><label>Target amount</label><input name="target" type="number" min="0" step="0.01" required value="${existing ? existing.target : ''}"></div>
      <div class="field"><label>Already saved</label><input name="saved" type="number" min="0" step="0.01" value="${existing ? existing.saved : 0}"></div>
      <div class="field"><label>Monthly contribution (for the calculator)</label><input name="monthly" type="number" min="0" step="0.01" value="${existing && existing.monthly ? existing.monthly : ''}" placeholder="e.g. 1000"></div>
      <div class="btn-row">
        ${existing ? `<button type="button" class="btn btn-danger" data-action="delete-goal" data-id="${existing.id}">Delete</button>` : ''}
        <button type="submit" class="btn btn-primary">${existing ? 'Update' : 'Add goal'}</button>
      </div>
    </form>
  `;
}

function loansModalHtml() {
  return `
    <div class="modal-head"><h3>Loan checker</h3><button class="modal-close" data-close>${X_ICON}</button></div>
    <div class="summary-bar">
      <div class="summary-pill summary-pill--owed"><span>Owed to you</span><strong id="loanOwedTotal"></strong></div>
      <div class="summary-pill summary-pill--owe"><span>You owe</span><strong id="loanOweTotal"></strong></div>
    </div>
    <div class="list-editable" id="loanRows"></div>
    <form id="formLoan">
      <div class="field"><label>Person</label><input name="person" required placeholder="e.g. Arjun" autofocus></div>
      <div class="field">
        <label>Direction</label>
        <div class="segmented" data-hidden-input="direction">
          <button type="button" class="is-active" data-value="owed_to_me">Owes me</button>
          <button type="button" data-value="i_owe">I owe</button>
        </div>
      </div>
      <input type="hidden" name="direction" value="owed_to_me">
      <div class="field"><label>Amount</label><input name="amount" type="number" min="0" step="0.01" required></div>
      <div class="field"><label>Note (optional)</label><input name="note" type="text" placeholder="e.g. Lent for concert tickets"></div>
      <div class="btn-row"><button type="submit" class="btn btn-primary">Add</button></div>
    </form>
  `;
}

function loanEditHtml(loan) {
  return `
    <div class="modal-head">
      <div class="modal-head-left">
        <button class="modal-close" data-action="back-to-loans" title="Back">
          <svg viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="#111" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <h3>Edit loan</h3>
      </div>
      <button class="modal-close" data-close>${X_ICON}</button>
    </div>
    <form id="formLoanEdit">
      <input type="hidden" name="id" value="${loan.id}">
      <div class="field"><label>Person</label><input name="person" required value="${esc(loan.person)}" autofocus></div>
      <div class="field">
        <label>Direction</label>
        <div class="segmented" data-hidden-input="direction">
          <button type="button" class="${loan.direction === 'owed_to_me' ? 'is-active' : ''}" data-value="owed_to_me">Owes me</button>
          <button type="button" class="${loan.direction === 'i_owe' ? 'is-active' : ''}" data-value="i_owe">I owe</button>
        </div>
      </div>
      <input type="hidden" name="direction" value="${loan.direction}">
      <div class="field"><label>Amount</label><input name="amount" type="number" min="0" step="0.01" required value="${loan.amount}"></div>
      <div class="field"><label>Note (optional)</label><input name="note" type="text" placeholder="e.g. Lent for concert tickets" value="${loan.note ? esc(loan.note) : ''}"></div>
      <div class="btn-row">
        <button type="button" class="btn btn-danger" data-action="delete-loan" data-id="${loan.id}">Delete</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  `;
}

function fillLoanModal() {
  const rows = document.getElementById('loanRows');
  if (!rows) return;
  if (!state.loans.length) {
    rows.innerHTML = '<p class="loan-empty">No loans tracked yet.</p>';
  } else {
    rows.innerHTML = state.loans.map(l => `
      <button class="row" data-action="edit-loan" data-id="${l.id}">
        <span class="row-text">
          <span class="row-main">${esc(l.person)} ${l.direction === 'owed_to_me' ? 'owes you' : 'you owe'}</span>
          ${l.note ? `<span class="row-note">${esc(l.note)}</span>` : ''}
        </span>
        <span class="row-amt ${l.direction === 'owed_to_me' ? 'pos' : 'neg'}">${formatMoney(l.amount)}</span>
      </button>
    `).join('');
  }
  document.getElementById('loanOwedTotal').textContent = formatMoney(
    state.loans.filter(l => l.direction === 'owed_to_me').reduce((s, l) => s + l.amount, 0)
  );
  document.getElementById('loanOweTotal').textContent = formatMoney(
    state.loans.filter(l => l.direction === 'i_owe').reduce((s, l) => s + l.amount, 0)
  );
}

function calcModalHtml() {
  const goalOptions = state.goals.map(g => `<option value="${g.id}">${esc(g.name)}</option>`).join('');
  return `
    <div class="modal-head"><h3>Goal calculator</h3><button class="modal-close" data-close>${X_ICON}</button></div>
    <form id="formCalc">
      ${state.goals.length ? `
      <div class="field">
        <label>Use an existing goal</label>
        <select name="goalId">
          <option value="">Custom numbers</option>
          ${goalOptions}
        </select>
      </div>` : ''}
      <div class="field"><label>Target amount</label><input name="target" type="number" min="0" step="0.01" required placeholder="e.g. 8000"></div>
      <div class="field"><label>Already saved</label><input name="saved" type="number" min="0" step="0.01" value="0"></div>
      <div class="field"><label>Monthly contribution</label><input name="monthly" type="number" min="0" step="0.01" required placeholder="e.g. 1000"></div>
      <div class="btn-row"><button type="submit" class="btn btn-primary">Calculate</button></div>
    </form>
    <div class="result-box" id="calcResult"></div>
  `;
}

/* ===================== Form submit handlers ===================== */

function submitTxn(data) {
  const amount = parseFloat(data.amount);
  if (!amount || amount <= 0) { toast('Enter a valid amount'); return; }

  if (data.type === 'income') {
    state.balance += amount;
    toast('Income added');
  } else {
    const bank = state.banks.find(b => b.id === data.bankId);
    if (!bank) { toast('Add a bank account first'); return; }
    if (amount > bank.balance) { toast(`Not enough balance in ${bank.name}`); return; }

    bank.balance -= amount;
    state.balance -= amount;
    state.expenses.push({
      id: uid(),
      category: data.category || 'Other',
      amount,
      note: (data.note || '').trim(),
      date: new Date().toISOString(),
      bankId: bank.id
    });
    toast('Expense added');
  }
  saveState();
  closeModal();
  renderHome();
  renderDashboard();
}

function submitBank(data) {
  const name = (data.name || '').trim();
  const balance = parseFloat(data.balance);
  if (!name || isNaN(balance)) { toast('Fill in account name & balance'); return; }

  const idx = state.banks.findIndex(b => b.id === data.id);
  if (idx > -1) {
    state.balance += balance - state.banks[idx].balance;
    state.banks[idx] = { ...state.banks[idx], name, balance };
  } else {
    state.balance += balance;
    state.banks.push({ id: uid(), name, balance });
  }

  saveState();
  closeModal();
  renderHome();
  toast('Saved');
}

function submitGoal(data) {
  const name = (data.name || '').trim();
  const target = parseFloat(data.target);
  const saved = parseFloat(data.saved) || 0;
  const monthly = parseFloat(data.monthly) || undefined;
  if (!name || !target || target <= 0) { toast('Fill in a name & target amount'); return; }

  const idx = state.goals.findIndex(g => g.id === data.id);
  if (idx > -1) state.goals[idx] = { ...state.goals[idx], name, target, saved, monthly };
  else state.goals.push({ id: uid(), name, target, saved, monthly });

  saveState();
  closeModal();
  renderHome();
  toast('Saved');
}

function submitLoan(form, data) {
  const person = (data.person || '').trim();
  const amount = parseFloat(data.amount);
  const direction = data.direction === 'i_owe' ? 'i_owe' : 'owed_to_me';
  if (!person || !amount || amount <= 0) { toast('Fill in person & amount'); return; }

  state.loans.push({ id: uid(), person, amount, direction, note: (data.note || '').trim() });
  saveState();

  form.reset();
  resetSegmented(form);
  fillLoanModal();
  renderHome();
  toast('Loan added');
}

function submitLoanEdit(data) {
  const idx = state.loans.findIndex(l => l.id === data.id);
  if (idx === -1) return;
  const person = (data.person || '').trim();
  const amount = parseFloat(data.amount);
  const direction = data.direction === 'i_owe' ? 'i_owe' : 'owed_to_me';
  if (!person || !amount || amount <= 0) { toast('Fill in person & amount'); return; }

  state.loans[idx] = { ...state.loans[idx], person, amount, direction, note: (data.note || '').trim() };
  saveState();

  openModal(loansModalHtml()); fillLoanModal();
  renderHome();
  toast('Loan updated');
}

function submitCalc(data) {
  const target = parseFloat(data.target) || 0;
  const saved = parseFloat(data.saved) || 0;
  const monthly = parseFloat(data.monthly) || 0;
  const box = document.getElementById('calcResult');
  box.innerHTML = describeGoalPrediction(target, saved, monthly);
  box.classList.add('is-visible');
}

/* ===================== Event wiring ===================== */

function wireNav() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => switchScreen(btn.dataset.screen));
  });
}

function wireHomeButtons() {
  document.getElementById('btnAddFunds').addEventListener('click', () => openModal(txnModalHtml('expense')));
  document.getElementById('btnMonthSpend').addEventListener('click', () => switchScreen('dashboard'));
  document.getElementById('btnAddExpense').addEventListener('click', () => openModal(txnModalHtml('expense')));
  document.getElementById('btnAddBank').addEventListener('click', () => openModal(bankFormHtml(null)));
  document.getElementById('btnAddGoal').addEventListener('click', () => openModal(goalFormHtml(null)));
  document.getElementById('btnOpenLoans').addEventListener('click', () => { openModal(loansModalHtml()); fillLoanModal(); });
  document.getElementById('btnOpenCalc').addEventListener('click', () => openModal(calcModalHtml()));

  document.getElementById('bankList').addEventListener('click', e => {
    const item = e.target.closest('.bank-item');
    if (!item) return;
    const bank = state.banks.find(b => b.id === item.dataset.id);
    if (bank) openModal(bankFormHtml(bank));
  });

  document.getElementById('goalList').addEventListener('click', e => {
    if (e.target.closest('#btnAddGoalInline')) { openModal(goalFormHtml(null)); return; }
    const card = e.target.closest('.goal-card');
    if (!card) return;
    const goal = state.goals.find(g => g.id === card.dataset.id);
    if (goal) openModal(goalFormHtml(goal));
  });
}

function toggleBalanceFace() {
  const showingBanks = document.getElementById('faceBanks').classList.contains('is-active');
  document.getElementById('faceTotal').classList.toggle('is-active', showingBanks);
  document.getElementById('faceBanks').classList.toggle('is-active', !showingBanks);
}

function wireBalanceSwipe() {
  const card = document.getElementById('balanceCard');
  let startX = null;
  let startY = null;
  card.addEventListener('pointerdown', e => { startX = e.clientX; startY = e.clientY; });
  card.addEventListener('pointerup', e => {
    if (startX === null) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    startX = null;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) toggleBalanceFace();
  });
}

function wireChart() {
  document.getElementById('chartBars').addEventListener('click', e => {
    const bar = e.target.closest('.chart-bar');
    if (!bar) return;
    const cat = bar.dataset.cat;
    selectedCategory = selectedCategory === cat ? null : cat;
    renderChart();
  });

  document.getElementById('detailList').addEventListener('click', e => {
    const btn = e.target.closest('[data-action="delete-expense"]');
    if (!btn) return;
    deleteExpense(btn.dataset.id);
  });
}

/* ===================== Init ===================== */

function init() {
  renderHome();
  renderDashboard();
  wireNav();
  wireHomeButtons();
  wireBalanceSwipe();
  wireChart();
}

document.addEventListener('DOMContentLoaded', init);
