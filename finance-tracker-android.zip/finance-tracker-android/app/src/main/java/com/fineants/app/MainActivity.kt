package com.fineants.app

import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * Fineants is a static HTML/CSS/JS app (see app/src/main/assets) that persists
 * its data with localStorage. This Activity is just a full-screen WebView
 * host for it — all the real logic lives in the bundled assets.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.setBackgroundColor(Color.parseColor("#FFF8EC"))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true // required for localStorage
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
